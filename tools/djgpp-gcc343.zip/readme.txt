put these files in a temporary directory on your hard disk ( i.e. c:\download ):

install.bat
seal107p.zip
zvg_pat.zip
ftp://ftp.info-zip.org/pub/infozip/MSDOS/unz551x3.exe
ftp://ftp.info-zip.org/pub/infozip/WIN32/unz551xN.exe
http://clio.rice.edu/cwsdpmi/csdpmi5b.zip
ftp://ftp.delorie.com/pub/djgpp/beta/v2/djdev204.zip
ftp://ftp.delorie.com/pub/djgpp/current/v2gnu/bnu215b.zip
ftp://ftp.delorie.com/pub/djgpp/current/v2gnu/dif281b.zip
ftp://ftp.delorie.com/pub/djgpp/current/v2gnu/fil41b.zip
ftp://ftp.delorie.com/pub/djgpp/current/v2gnu/gcc343b.zip
ftp://ftp.delorie.com/pub/djgpp/beta/v2gnu/mak380b.zip
ftp://ftp.delorie.com/pub/djgpp/current/v2gnu/pat254b.zip
http://upx.sourceforge.net/download/upx125d.zip
http://upx.sourceforge.net/download/upx125w.zip
http://voxel.dl.sourceforge.net/sourceforge/nasm/nasm-0.98.38-win32.zip
http://voxel.dl.sourceforge.net/sourceforge/nasm/nasm-0.98.38-djgpp.zip
http://voxel.dl.sourceforge.net/sourceforge/alleg/all4118.zip
http://files1.sonicspot.com/sealsdk/seal107.zip
http://www.zektor.com/zvg/downloads/zvg_sdk11a.zip

then execute install.bat

links:
http://www.info-zip.org/
http://clio.rice.edu/cwsdpmi/
http://clio.rice.edu/djgpp/win2k/main_204.htm
http://upx.sourceforge.net/
http://alleg.sourceforge.net/
http://nasm.sourceforge.net/
http://www.sonicspot.com/sealsdk/sealsdk.html
http://www.zektor.com/zvg/zvg_download.htm
