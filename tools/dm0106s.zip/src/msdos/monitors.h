/* supported monitor types */
#define MONITOR_TYPE_STANDARD	0
#define MONITOR_TYPE_NTSC		1
#define MONITOR_TYPE_PAL		2
#define MONITOR_TYPE_ARCADE		3

